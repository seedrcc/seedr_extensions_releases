# Seedr Repository for Kodi

This repository contains the Seedr addon for Kodi.

## Quick Downloads

👉 **[DOWNLOAD REPOSITORY.SEEDR-1.0.7.ZIP](./REPOSITORY.SEEDR-1.0.7.ZIP)** - Install this first!  
👉 **[DOWNLOAD PLUGIN.VIDEO.SEEDR-1.0.7.ZIP](../plugin.video.seedr/PLUGIN.VIDEO.SEEDR-1.0.7.ZIP)** - Seedr addon

## Navigation

<pre>
<img src="../icons/folder.gif" alt="[DIR]"> <a href="../">Parent Directory</a>
<img src="../icons/compressed.gif" alt="[ZIP]"> <a href="../REPOSITORY.SEEDR-1.0.7.ZIP">REPOSITORY.SEEDR-1.0.7.ZIP</a>
</pre>

## Download

- [REPOSITORY.SEEDR-1.0.7.ZIP](../REPOSITORY.SEEDR-1.0.7.ZIP) - Repository ZIP file
- [REPOSITORY.SEEDR-1.0.7.ZIP.md5](../REPOSITORY.SEEDR-1.0.7.ZIP.md5) - MD5 Checksum: `03efc34e16918b87188c7a804d910248`

## Installation

### Step-by-Step Guide: Installing the Seedr Repository in Kodi

**IMPORTANT:** Copy the ZIP file to a simple path first (e.g., `D:\kodi-addons\REPOSITORY.SEEDR-1.0.7.ZIP`) to avoid issues with spaces in the path.

#### Step 1: Enable Unknown Sources (First Time Only)

1. Open Kodi and click the **Settings** icon (gear icon) at the top left
2. Select **System** (or **System Settings**)
3. Click on **Add-ons** in the left menu
4. Toggle **Unknown sources** to ON
5. Click **Yes** when the warning appears

#### Step 2: Install the Repository ZIP File

1. Go back to the Kodi home screen
2. Click on **Add-ons** in the left menu
3. Click on the **Package installer** icon (open box icon) at the top left
4. Select **Install from zip file**
5. Browse to where you saved the repository ZIP file:
   - Navigate to `D:\kodi-addons\` (or wherever you copied the file)
   - Select `REPOSITORY.SEEDR-1.0.7.ZIP`
6. Click **OK**
7. Wait for the notification: **"Seedr Repository Add-on installed"**

#### Step 3: Install the Seedr Addon from the Repository

1. From the Package installer menu, select **Install from repository**
2. Select **Seedr Repository**
3. Click on **Video add-ons**
4. Select **Seedr**
5. Click **Install**
6. Wait for dependencies to install (if any)
7. Wait for the notification: **"Seedr Add-on installed"**

#### Step 4: Configure the Seedr Addon

1. Go to **Add-ons** > **Video add-ons**
2. Select **Seedr**
3. Follow the on-screen authentication instructions:
   - A verification URL and code will be displayed
   - Visit the URL in your web browser
   - Enter the verification code
   - Authorize the application
4. Return to Kodi and start browsing your Seedr files!

### Troubleshooting

**Issue:** "Install from zip file" option is greyed out
- **Solution:** Enable "Unknown sources" in Settings > System > Add-ons

**Issue:** Error installing the ZIP file
- **Solution:** Copy the ZIP to a simple path without spaces (e.g., `D:\kodi-addons\`)

**Issue:** Repository installed but addon not showing
- **Solution:** Wait a few seconds and refresh. Check Settings > Add-ons > Manage dependencies

**Issue:** Authentication fails
- **Solution:** Check your internet connection and ensure you have a valid Seedr account

## Available Addons

- **Seedr v1.2.0** - Stream videos, music, and images from your Seedr cloud storage directly to Kodi
  - Fixed critical indentation errors in main.py
  - Improved code stability and reliability
  - Better error handling for authentication flow
  - Enhanced compatibility with Kodi installation process

## Repository Structure

This repository follows the standard Kodi repository structure:

- `addons.xml` - Contains metadata for all addons in the repository
- `addons.xml.md5` - MD5 hash of the addons.xml file for verification
- `plugin.video.seedr/` - The Seedr addon
- `repository.seedr/` - The repository addon itself
