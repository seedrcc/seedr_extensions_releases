# Seedr Addon Language Files

This directory contains language files for the Seedr Kodi addon.

## Navigation

<pre>
<img src="../../../icons/folder.gif" alt="[DIR]"> <a href="../">Parent Directory</a>
<img src="../../../icons/folder.gif" alt="[DIR]"> <a href="resource.language.en_gb/">resource.language.en_gb/</a>
</pre>

## Contents

- `resource.language.en_gb/` - English (GB) language strings
