# Seedr Addon Resources

This directory contains resources used by the Seedr Kodi addon.

## Navigation

<pre>
<img src="../../icons/folder.gif" alt="[DIR]"> <a href="../">Parent Directory</a>
<img src="../../icons/folder.gif" alt="[DIR]"> <a href="language/">language/</a>
</pre>

## Contents

- `settings.xml` - Settings configuration for the addon
- `language/` - Contains language files for localization
