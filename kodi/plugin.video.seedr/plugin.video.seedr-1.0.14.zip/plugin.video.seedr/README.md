# Seedr Kodi Addon

Stream videos, music, and images from your Seedr cloud storage directly to Kodi.

## Quick Downloads

👉 **[DOWNLOAD REPOSITORY.SEEDR-1.0.7.ZIP](../repository.seedr/REPOSITORY.SEEDR-1.0.7.ZIP)** - Install this first!  
👉 **[DOWNLOAD PLUGIN.VIDEO.SEEDR-1.0.7.ZIP](./PLUGIN.VIDEO.SEEDR-1.0.7.ZIP)** - Seedr addon

## Navigation

<pre>
<img src="../icons/folder.gif" alt="[DIR]"> <a href="../">Parent Directory</a>
<img src="../icons/compressed.gif" alt="[ZIP]"> <a href="./PLUGIN.VIDEO.SEEDR-1.0.7.ZIP">PLUGIN.VIDEO.SEEDR-1.0.7.ZIP</a>
</pre>

## Download

- [PLUGIN.VIDEO.SEEDR-1.0.7.ZIP](./PLUGIN.VIDEO.SEEDR-1.0.7.ZIP) - Addon ZIP file
- [PLUGIN.VIDEO.SEEDR-1.0.7.ZIP.md5](./PLUGIN.VIDEO.SEEDR-1.0.7.ZIP.md5) - MD5 Checksum: `842fff03bf19baa2895b6ad18a64f677`

## Installation

1. Download the addon repository zip file ([REPOSITORY.SEEDR-1.0.7.ZIP](../repository.seedr/REPOSITORY.SEEDR-1.0.7.ZIP))
2. In Kodi, go to Add-ons > Install from zip file
3. Select the downloaded zip file
4. The repository will be installed, and you can then install the Seedr addon from the repository

**Alternative:** Install directly from [PLUGIN.VIDEO.SEEDR-1.0.7.ZIP](./PLUGIN.VIDEO.SEEDR-1.0.7.ZIP)

**Note:** If you have issues with paths containing spaces, copy the ZIP file to a simple path like `D:\kodi-addons-install\` before installing.

## Usage

1. Launch the addon
2. You will be prompted to authenticate with Seedr
3. Follow the on-screen instructions to complete authentication
4. Browse and stream your content

## Requirements

- Kodi 19.0 (Matrix) or higher
- Internet connection
- Seedr account

