' ********** Token Refresh Task - Async Token Validation and Refresh **********

sub init()
    m.top.functionName = "checkAndRefreshToken"
end sub

' Main task function - runs in background thread
sub checkAndRefreshToken()
    print "[TokenRefreshTask] ==================== STARTING TOKEN CHECK ===================="
    print "[TokenRefreshTask] Task started at: "; CreateObject("roDateTime").AsSeconds()
    
    result = {
        success: false
        needsAuth: true
        error: ""
        tokenRefreshed: false
    }
    
    ' Load credentials from registry
    credentials = loadCredentials()
    
    if credentials = invalid then
        print "[TokenRefreshTask] No credentials found - user needs to authenticate"
        result.needsAuth = true
        result.error = "No credentials found"
        m.top.result = result
        return
    end if
    
    print "[TokenRefreshTask] Credentials found, checking validity..."
    print "[TokenRefreshTask] Token age check starting..."
    
    ' Check token age
    currentTime = CreateObject("roDateTime").AsSeconds()
    tokenAge = currentTime - credentials.authTime
    tokenAgeDays = Int(tokenAge / 86400)
    
    print "[TokenRefreshTask] Token age: "; tokenAgeDays; " days ("; tokenAge; " seconds)"
    
    ' Token validity threshold: 30 days
    maxTokenAge = 2592000 ' 30 days in seconds
    
    if tokenAge < maxTokenAge then
        ' Token is still valid - no refresh needed
        print "[TokenRefreshTask] ✓ Token is valid ("; tokenAgeDays; " days old, < 30 days)"
        result.success = true
        result.needsAuth = false
        result.tokenRefreshed = false
        m.top.result = result
        print "[TokenRefreshTask] Task completed successfully - token valid"
        return
    end if
    
    ' Token is expired - attempt refresh
    print "[TokenRefreshTask] ⚠ Token expired ("; tokenAgeDays; " days old)"
    print "[TokenRefreshTask] Attempting token refresh with refresh token..."
    
    if credentials.refreshToken = invalid or credentials.refreshToken = "" then
        print "[TokenRefreshTask] ERROR: No refresh token available"
        result.needsAuth = true
        result.error = "No refresh token available"
        
        ' Clear expired credentials
        print "[TokenRefreshTask] Clearing expired credentials from registry..."
        clearCredentials()
        
        m.top.result = result
        return
    end if
    
    ' Attempt to refresh the token (async call)
    print "[TokenRefreshTask] Calling refreshAccessToken()..."
    newTokens = refreshAccessToken(credentials.refreshToken)
    
    if newTokens <> invalid and newTokens.access_token <> invalid then
        ' Refresh successful!
        print "[TokenRefreshTask] ✓✓✓ Token refresh SUCCESSFUL! ✓✓✓"
        print "[TokenRefreshTask] New access token received"
        
        ' Save new tokens
        refreshTokenValue = ""
        if newTokens.refresh_token <> invalid then
            refreshTokenValue = newTokens.refresh_token
            print "[TokenRefreshTask] New refresh token also received"
        else
            ' Use old refresh token if new one not provided
            refreshTokenValue = credentials.refreshToken
            print "[TokenRefreshTask] Using existing refresh token (new one not provided)"
        end if
        
        print "[TokenRefreshTask] Saving new credentials to registry..."
        saveCredentials(newTokens.access_token, refreshTokenValue)
        print "[TokenRefreshTask] New credentials saved successfully"
        
        result.success = true
        result.needsAuth = false
        result.tokenRefreshed = true
        result.error = ""
        
        print "[TokenRefreshTask] Task completed successfully - token refreshed"
        m.top.result = result
        return
    else
        ' Refresh failed - user needs to re-authenticate
        print "[TokenRefreshTask] ✗✗✗ Token refresh FAILED ✗✗✗"
        
        if newTokens <> invalid and newTokens.error <> invalid then
            print "[TokenRefreshTask] API Error: "; newTokens.error
            result.error = "Token refresh failed: " + newTokens.error
        else
            print "[TokenRefreshTask] Network error or invalid response"
            result.error = "Token refresh failed: Network error"
        end if
        
        result.needsAuth = true
        result.success = false
        result.tokenRefreshed = false
        
        ' Clear invalid credentials from registry
        print "[TokenRefreshTask] Clearing invalid credentials from registry..."
        clearCredentials()
        print "[TokenRefreshTask] Credentials cleared - user must re-authenticate"
        
        m.top.result = result
        print "[TokenRefreshTask] Task completed - re-authentication required"
        return
    end if
    
    print "[TokenRefreshTask] =============================================================="
end sub

